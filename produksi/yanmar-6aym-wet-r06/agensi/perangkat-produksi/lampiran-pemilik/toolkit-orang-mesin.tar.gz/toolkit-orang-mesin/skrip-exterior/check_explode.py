import bpy, json, os, sys, itertools
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
OUT = "/tmp/claude-0/c3512/model/exterior"
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, "exterior.blend"))
frac = float(os.environ.get("FRAC", "1.0"))
res = {}
for f in sorted(os.listdir(os.path.join(OUT, "assemblies"))):
    A = json.load(open(os.path.join(OUT, "assemblies", f)))
    objs = {}
    for b in A["bagian"]:
        for p in b["posisi"]:
            d = Vector(p["arah"]) * p["jarak_m"] * frac
            off = Vector((d.x, -d.z, d.y))
            ob = bpy.data.objects[p["object_id"]]
            me = ob.data
            mw = Matrix.Translation(off) @ ob.matrix_world
            verts = [mw @ v.co for v in me.vertices]
            polys = [list(pp.vertices) for pp in me.polygons]
            objs[p["object_id"]] = BVHTree.FromPolygons(verts, polys, all_triangles=False)
    bad = []
    for a, b in itertools.combinations(objs, 2):
        n = len(objs[a].overlap(objs[b]))
        if n: bad.append((a, b, n))
    res[A["id"]] = dict(objek=len(objs), pasangan_menembus=bad)
    print(A["id"], len(objs), "overlap pairs:", len(bad), bad[:12])
json.dump(res, open(os.path.join(OUT, f"explode_check_{frac:.2f}.json"), "w"), indent=1)
