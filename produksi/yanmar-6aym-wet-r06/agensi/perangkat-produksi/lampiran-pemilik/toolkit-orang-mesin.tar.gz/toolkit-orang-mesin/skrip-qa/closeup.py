import bpy, mathutils, math
exec(open('render.py').read().split("views={")[0])
cam.type='PERSP'; cam.lens=50
shots={'detail_turbo':((-1.6,1.9,1.9),(-0.3,0.85,0.5)),'detail_kepala_blok':((1.2,1.2,2.6),(0.9,0.4,0.4)),'detail_internal_xsec':((0.9,0.9,3.4),(0.9,0.3,0.0)),'detail_flywheel':((-1.6,0.2,1.3),(-0.2,0.0,0.0))}
for n,(eye,tgt) in shots.items():
    e=D2B(*eye); t=D2B(*tgt); co.location=e; co.rotation_euler=(t-e).to_track_quat('-Z','Y').to_euler()
    for o in bpy.data.objects:
        if o.name.startswith('EXT-'): o.hide_render=(n=='detail_internal_xsec')
    sc.render.filepath=f'/tmp/claude-0/c3512/qa/render/qa_{n}.png'; bpy.ops.render.render(write_still=True); print('done',n)
