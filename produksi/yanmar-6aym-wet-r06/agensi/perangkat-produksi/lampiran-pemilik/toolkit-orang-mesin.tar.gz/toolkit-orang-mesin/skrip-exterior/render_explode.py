import bpy, json, os, math
from mathutils import Vector
OUT = "/tmp/claude-0/c3512/model/exterior"
FRAC = float(os.environ.get("FRAC", "0.5"))
for aid in os.environ.get("ASMS", "EXT-HX,EXT-TRB-R").split(","):
    bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, "exterior.blend"))
    sc = bpy.context.scene
    A = json.load(open(os.path.join(OUT, "assemblies", aid + ".json")))
    keep = set()
    for b in A["bagian"]:
        for p in b["posisi"]:
            d = Vector(p["arah"]) * p["jarak_m"] * FRAC
            ob = bpy.data.objects[p["object_id"]]
            ob.location += ob.matrix_parent_inverse.inverted().to_3x3() @ Vector((d.x, -d.z, d.y)) if False else Vector((d.x, -d.z, d.y))
            keep.add(p["object_id"])
    for ob in sc.objects:
        if ob.type == "MESH" and ob.name not in keep:
            ob.hide_render = True
    bpy.context.view_layer.update()
    pts = [ob.matrix_world @ Vector(c) for ob in sc.objects if ob.name in keep for c in ob.bound_box]
    lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    cen = (lo + hi) / 2; rad = (hi - lo).length / 2
    v = Vector(A["diagram"]["arah_pandang"]).normalized(); vb = Vector((v.x, -v.z, v.y))
    cam_d = bpy.data.cameras.new("c"); cam_d.lens = 50; cam = bpy.data.objects.new("c", cam_d); sc.collection.objects.link(cam); sc.camera = cam
    dist = rad / math.tan(math.radians(18)) * 1.05
    cam.location = cen - vb * dist
    cam.rotation_euler = vb.to_track_quat("-Z", "Y").to_euler()
    sc.render.engine = "CYCLES"; sc.cycles.device = "CPU"; sc.cycles.samples = 24; sc.cycles.use_denoising = True
    sc.render.resolution_x, sc.render.resolution_y = 1200, 900
    sc.view_settings.view_transform = "Standard"
    NEU = bpy.data.materials.new("N"); NEU.use_nodes = True
    bs = NEU.node_tree.nodes["Principled BSDF"]; bs.inputs["Base Color"].default_value = (0.66, 0.65, 0.62, 1); bs.inputs["Roughness"].default_value = 0.55
    sc.view_layers[0].material_override = NEU
    sc.world = bpy.data.worlds.new("W"); sc.world.use_nodes = True
    sc.world.node_tree.nodes["Background"].inputs[0].default_value = (0.012, 0.025, 0.045, 1)
    sc.world.node_tree.nodes["Background"].inputs[1].default_value = 1.0
    for i, (rot, en) in enumerate((((math.radians(45), 0, math.radians(35)), 3.5), ((math.radians(70), 0, math.radians(210)), 1.5))):
        ld = bpy.data.lights.new(f"s{i}", "SUN"); ld.energy = en; lo_ = bpy.data.objects.new(f"s{i}", ld); lo_.rotation_euler = rot; sc.collection.objects.link(lo_)
    sc.render.filepath = os.path.join(OUT, "render", f"explode{int(FRAC*100)}_{aid}.png")
    bpy.ops.render.render(write_still=True)
print("DONE")
